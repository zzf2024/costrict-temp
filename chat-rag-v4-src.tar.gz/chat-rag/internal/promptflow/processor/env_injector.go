package processor

import (
	"os"
	"path/filepath"
	"strings"

	"github.com/zgsm-ai/chat-rag/internal/logger"
	"github.com/zgsm-ai/chat-rag/internal/model"
	"go.uber.org/zap"
)

// EnvInjector appends environment-awareness guidance to the system prompt (改造3).
// It detects the project type from characteristic files and injects only
// relevant, generic guidance — no framework-specific commands.
type EnvInjector struct {
	BaseProcessor

	identity *model.Identity
}

// NewEnvInjector creates a new EnvInjector processor.
func NewEnvInjector(identity *model.Identity) *EnvInjector {
	return &EnvInjector{identity: identity}
}

// Execute appends environment-awareness guidance to the system prompt.
func (e *EnvInjector) Execute(promptMsg *PromptMsg) {
	const method = "EnvInjector.Execute"

	if promptMsg == nil {
		logger.Warn("received nil prompt message", zap.String("method", method))
		e.passToNext(promptMsg)
		return
	}

	// Only inject when we have a project path to reference
	if e.identity == nil || e.identity.ProjectPath == "" {
		e.passToNext(promptMsg)
		return
	}

	systemContent, err := e.extractSystemContent(promptMsg.GetSystemMsg())
	if err != nil {
		logger.Warn("failed to extract system content for env injection",
			zap.String("method", method), zap.Error(err))
		e.passToNext(promptMsg)
		return
	}

	envInfo := e.buildEnvInfo(e.identity.ProjectPath)

	promptMsg.UpdateSystemMsg(systemContent + envInfo)

	logger.Info("injected environment awareness into system prompt",
		zap.String("method", method),
		zap.String("projectPath", e.identity.ProjectPath))

	e.passToNext(promptMsg)
}

// buildEnvInfo generates environment-awareness guidance based on detected project type.
func (e *EnvInjector) buildEnvInfo(projectPath string) string {
	var sb strings.Builder

	sb.WriteString("\n\n====\n\nENVIRONMENT AWARENESS\n\n")
	sb.WriteString("Project path: " + projectPath + "\n\n")
	sb.WriteString("Before running commands, check the environment:\n")
	sb.WriteString("- Verify the language runtime version (e.g., `python --version`, `node --version`, `go version`)\n")
	sb.WriteString("- Check if a virtual environment or dependency manager is active and dependencies are installed\n")
	sb.WriteString("- Before running tests, look for existing test configuration in the project root (e.g., pytest.ini, package.json, go.mod, Makefile, tox.ini)\n")

	// Detect project type from characteristic files and add tailored hint
	projectType := e.detectProjectType(projectPath)
	if projectType != "" {
		sb.WriteString("\nDetected project type: " + projectType + "\n")
		switch projectType {
		case "python":
			sb.WriteString("- If a requirements.txt or pyproject.toml exists, ensure dependencies are installed in the active environment\n")
		case "node":
			sb.WriteString("- If a package.json exists, check the `scripts` section for the test command before inventing your own\n")
		case "go":
			sb.WriteString("- Ensure `go mod tidy` has been run if dependencies are missing\n")
		}
	}

	sb.WriteString("\n====\n")

	return sb.String()
}

// detectProjectType checks for characteristic files in the project root.
func (e *EnvInjector) detectProjectType(projectPath string) string {
	checks := map[string][]string{
		"python": {"manage.py", "pytest.ini", "setup.py", "pyproject.toml", "tox.ini", "requirements.txt"},
		"node":   {"package.json"},
		"go":     {"go.mod"},
	}

	for ptype, files := range checks {
		for _, f := range files {
			if _, err := os.Stat(filepath.Join(projectPath, f)); err == nil {
				return ptype
			}
		}
	}
	return ""
}
